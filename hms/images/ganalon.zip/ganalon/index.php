<?php

	session_start();
	include 'header.php';
	require_once('connect.php');

	if(isset($_POST['btnRegister'])){
		
        $band = mysql_real_escape_string($_POST['band']);
		$seat = mysql_real_escape_string($_POST['seat']);
		$ticketno = mysql_real_escape_string($_POST['ticketno']);
		$last = mysql_real_escape_string($_POST['last']);
		$first = mysql_real_escape_string($_POST['first']);
		$middle = mysql_real_escape_string($_POST['middle']);
		$age = mysql_real_escape_string($_POST['age']);
		$gender = mysql_real_escape_string($_POST['gender']);
		$address = mysql_real_escape_string($_POST['address']);
		$city = mysql_real_escape_string($_POST['city']);
		$contact = mysql_real_escape_string($_POST['contact']);
		$bday = mysql_real_escape_string($_POST['birthday']);
		$email = mysql_real_escape_string($_POST['email']);
		$email2 = mysql_real_escape_string($_POST['email2']);

		if($email==$email2){
			$sql = "INSERT INTO users(band,seat,ticketnum,last,first,middle,age,gender,address,city,contact,bday,email) VALUES('$band','$seat','$ticketno','$last','$first','$middle','$age','$gender','$address','$city','$contact','$bday', '$email')";
			mysqli_query($db, $sql);
			header("location: confirm.php");
		}

		else{
			header("location: error.php");

			}		

	}

		

?>

<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<style type="text/css">
	
	#content{
	font-size: 20;
	color:black;
	}

	</style>

</head>
<body>

	<form method="post" action="index.php">
	<div id="content">
	<center><strong><h2>Reservation Form:</h2>
        <b>Band Concert:</b><br>
        <input type="radio" name="band" value="Coldplay" required>Coldplay<br>
	    <input type="radio" name="band" value="Panic at the Disco" required>Panic! At The Disco<br>
  	    <input type="radio" name="band" value="21 pilots" required>Twenty One Pilots<br>
		<b>Seat type:</b><br>
		<input type="radio" name="seat" value="VIP" required> VIP ₱10,000<br>
	    <input type="radio" name="seat" value="Lower Box A" required> Lower Box A ₱5,000<br>
  	    <input type="radio" name="seat" value="Lower Box B" required> Lower Box B ₱3,000<br>
		<input type="radio" name="seat" value="Upper Box A" required> Upper Box A ₱2,000<br>
		<input type="radio" name="seat" value="Upper Box B" required> Upper Box B ₱1,000<br>
		<input type="radio" name="seat" value="General Admission" required> General Admission ₱500<br>
		Number oF Tickets(max. of 5 tickets only) <input type="text" name="ticketno" required><br>
		Last Name <input type="text" name="last" required><br>
		First Name <input type="text" name="first" required><br>
		Middle Initial <input type="text" name="middle" required><br>
		Age <input type="text" name="age" required><br>
		Gender <input type="radio" name="gender" value="Male" required> Male
			   <input type="radio" name="gender" value="female" required> Female<br>
		Address <input type="text" name="address" required><br>
		City <input type="text" name="city" required><br>
		Contact Number <input type="text" name="contact" required><br>
		Birthday(YYYY/MM/DD) <input type="text" name="birthday" required><br>
		Email <input type="text" name="email" required><br>
		Confirm Email <input type="text" name="email2" required><br>
		<input type="reset" value="Clear Entries">
		<input type="submit" name="btnRegister" value="Save"></strong></center>
		</div>

	</form>

</body>
</html>
<html>
<head>
<title>Concert Reservation</title>
<style type="text/css">
	body{
    background-image: url('./images/bg.jpeg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    color: #fff;
	}

	a {
	text-decoration: none;
	color:white;
	}
</style>
</head>
<body>
	<center><big><b><h1>In The Mix</h1></b></big></center>
</body>
</html>
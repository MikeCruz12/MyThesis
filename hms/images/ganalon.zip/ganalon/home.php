<!DOCTYPE html>
<html>
<head>
	<title>Concert Reservation</title>
	<?php
		include 'header.php';
	?>
</head>
<body>

	<center><img src="images/panic.jpeg" width="400" height="250">
	<img src="images/coldplay.jpeg" width="400" height="250">
	<img src="images/pilots.jpeg" width="400" height="250"></center>

	<center><big><a href="index.php">Sign up</a></big></center>
</body>
</html>
<?php
$db = mysqli_connect("localhost","root","","dbconnect");
?>
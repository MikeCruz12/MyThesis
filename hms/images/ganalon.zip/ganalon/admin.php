<?php
include 'header.php';
require_once('connect.php');

	$query = "SELECT id,band,seat,ticketnum,last,first,middle,age,gender,address,city,contact,bday,email FROM clients";

	$response = @mysqli_query($db,$query);

	if($response){
		echo '<table align="left"
		cellspacing="5" cellpadding="8">

		<tr>
		<td align="left"><b>ID</b></td>
		<td align="left"><b>Seat</b></td>
		<td align="left"><b>Number of Tickets</b></td>
		<td align="left"><b>Last Name</b></td>
		<td align="left"><b>First Name</b></td>
		<td align="left"><b>Middle Initial</b></td>
		<td align="left"><b>Age</b></td>
		<td align="left"><b>Gender</b></td>
		<td align="left"><b>Address</b></td>
		<td align="left"><b>City</b></td>
		<td align="left"><b>Contact Number</b></td>
		<td align="left"><b>Birthdate</b></td>
		<td align="left"><b>Email Address</b></td>
		</tr>';

		while($row = mysqli_fetch_array($response)){

			echo'<tr><td align="left">'.
			$row['id'].'</td><td align="left">'.
			$row['seats'].'</td><td align="left">'.
			$row['ticketNum'].'</td><td align="left">'.
			$row['lastn'].'</td><td align="left">'.
			$row['firstn'].'</td><td align="left">'.
			$row['midn'].'</td><td align="left">'.
			$row['age'].'</td><td align="left">'.
			$row['gender'].'</td><td align="left">'.
			$row['address'].'</td><td align="left">'.
			$row['city'].'</td><td align="left">'.
			$row['contact'].'</td><td align="left">'.
			$row['bday'].'</td><td align="left">'.
			$row['email'].'</td><td align="left">';

			echo '</tr>';

		}

		echo '</table>';
	}else{
		echo "Error";
		echo mysqli_error($db);
	}
	

mysqli_close($db);

?>
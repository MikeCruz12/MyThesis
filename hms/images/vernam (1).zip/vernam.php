<?php
/*
Copyright (C) 2003 Enders Web Development

This program is free software; you can redistribute it and/or modify it under 
the terms of the GNU General Public License as published by the Free Software 
Foundation; either version 2 of the License, or (at your option) any later 
version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY 
WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A 
PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with 
this program; if not, write to the 
Free Software Foundation, Inc., 
59 Temple Place - Suite 330, 
Boston, MA 02111-1307, USA.

Author Email: tomender@ptd.net
Author Post:
J. Thomas Enders
PO Box 663
Gilbert, PA 18331, USA
*/

  error_reporting(E_ALL);
  
  //ensure we don't get errors on initial load
  if(!isset($_POST['key'])) {$_POST['key'] = '';}
  if(!isset($_POST['plaintext'])) {$_POST['plaintext'] = '';}
  if(!isset($_POST['ciphertext'])) {$_POST['ciphertext'] = '';}
  
  //data scrubbing
  $parse = false;
  $error = '';
  if(isset($_POST['encrypt']) || isset($_POST['decrypt'])) {
      $parse = true;
      if((isset($_POST['encrypt']) || isset($_POST['decrypt']))) {
          if($_POST['key'] == '') {
              $error .= "ERROR: You must enter a key to encrypt or decrypt text.<br />\n";
              $parse = false;
          } elseif(!eregi("^[a-z]+$",$_POST['key'])) {
              $error .= "ERROR: The key (" . $_POST['key'] . ") can only contain letters.<br />\n";
              $parse = false;
          }
      } //end if
    
      if(isset($_POST['encrypt']) && $_POST['plaintext'] == '') {
          $error .= "ERROR: You must enter pleantext to encrypt.<br />\n";
          $parse = false;
      } elseif (isset($_POST['decrypt']) && $_POST['ciphertext'] == '') {
          $error .= "ERROR: You must enter ciphertext to decrypt.<br />\n";
          $parse = false;
      } //end if
  } //end if
  
  if ($parse && isset($_POST['encrypt'])) {
      $_POST['ciphertext'] = encrypt($_POST['key'],$_POST['plaintext']);
  } elseif ($parse && isset($_POST['decrypt'])) {
      $_POST['plaintext'] = decrypt($_POST['key'],$_POST['ciphertext']);
  } 

  echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Vernam Cipher</title>
<style type="text/css">
    body {
        font-family: arial,helvetica,_sans;
        font-size: 11pt;
        color: #000000;
        background-color: #FFFFEE;
    }
    
    div.dataScrubbing {
        position: absolute;
        padding: 5px;
        background-color: #EEFFFF;
        border-width: 1px;
        border-color: #888899;
        border-style: solid;
        color: #990000;
        width: 375px;
    }
    
    div.inputArea {
        background-color: #FFFFFF;
        position: absolute;
        padding: 5px;
        border-width: 1px;
        border-color: #000000;
        border-style: solid;
        width: 380px;
    }
    
    input,textarea {
        font-family: arial,helvetica,_sans;
        font-size: 11pt;
        color: #000000;
        background-color: #EEFFFF;
        border-width: 1px;
        border-color: #889999;
        border-style: solid;
    }
</style>
</head>
<body>
<h1>Vernam Cipher</h1>

<?php
    if($error != '') {
        echo '<div class="dataScrubbing">' . "\n";
        echo $error;
        echo "</div>\n";
        echo "<div><br /><br /></div>\n";
    } //end if
?>

<div class="inputArea">
  <form method="post" action="<?=$_SERVER['PHP_SELF']?>">
    Enter the key: <input type="text" name="key" size="20" value="<?=$_POST['key']?>" /><br />
    Plaintext:<br />
    <textarea name="plaintext" cols="50" rows="5"><?=$_POST['plaintext']?></textarea><br />
    Ciphertext:<br />
    <textarea name="ciphertext" cols="50" rows="5"><?=$_POST['ciphertext']?></textarea><br /><br />
    <input type="submit" name="encrypt" value="Encrypt" />&nbsp;&nbsp;
    <input type="submit" name="decrypt" value="Decrypt" />
  </form>
</div>
</body>
</html>

<?php
  function encrypt($key,$text) {
      $key = strtolower($key);

      //prepare the text for encryption
      preptext($text,'enc');
      
      //create the one time pad
      $key .= $text;
      
      $retval = '';
      //loop through the plain text to encrypt it.
      for($i=0;$i<strlen($text);$i++) {
          //get the current letter's placement in 
          //the alphabet using its ascii value
          $cur_char = ord(substr($text,$i,1)) - 97;
          
          //get the current key letter's placement  
          //in the alphabet using its ascii value
          $cur_key = ord(substr($key,$i,1)) - 97;

          //encrypt the current character and append it to
          //the return value                      
          $retval .= chr(($cur_char + $cur_key)%26 + 65);
      } //end for
      return $retval;
  } //end encrypt
  
  function decrypt($key,$text) {
      $key = strtoupper($key);
      //prepare the text for decryption
      preptext($text,'dec');
      
      $retval = '';
      
      //outer loop adds blocks of the key onto the key 
      //as they are decrypted
      $i_inc = strlen($key); //block size
      $str_len = strlen($text);
      $retval = '';
      for($i=0;$i<$str_len;$i = $i + $i_inc) {
          //since the decrypted plain text is lower case we have
          //to uppercase the blocks as we add them
          $key .= strtoupper(substr($retval,($i-$i_inc),$i_inc));
          
          //inner loop to actually decrypt the text
          for($j=0;$j<$i_inc;$j++) {
              //position of the current character in the alphabet
              $cur_char = ord(substr($text,($i+$j),1)) - 65;
              
              //position of the current key letter in the alphabet
              $cur_key = ord(substr($key,($i+$j),1)) - 65;
              
              //position of the current plaintext letter in the alphabet
              $cur_dec = $cur_char - $cur_key;
              
              //workaround of mod bug in php which leaves negatives
              if($cur_dec > -1) {$cur_dec = $cur_dec + 97;}
              else {$cur_dec = (26 + $cur_dec)+ 97;}
              
              //make sure we don't get junk characters at the end 
              //of the decrypted text
              if(($i+$j) < $str_len) {$retval .= chr($cur_dec);}
          } //end for
      } //end for
      return $retval;
  } //end decrypt
  
  function preptext(&$text,$direction = 'enc') {
      $direction = strtolower($direction);

      if($direction != 'enc' && $direction != 'dec') {
          warn("preptext called with an inappropriate direction value.");
      }
      
      switch ($direction) {
          case 'enc';
              $text = strtolower($text);
              $low_bound = 95; //ascii value of a
              $high_bound = 122; //ascii value of z
              break;
          case 'dec';
              $text = strtoupper($text);
              $low_bound = 65; //ascii value of A
              $high_bound = 90; //ascii value of Z
      } //end switch
      
      //saves clock ticks
      $t_len = strlen($text);
      //remove all non-alphabetic characters
      for($i=0;$i<$t_len;$i++) {
          if(ord(substr($text,$i,1)) < $low_bound ||
              ord(substr($text,$i,1)) > $high_bound) {
              $text = substr($text,0,$i) . substr($text,($i+1));
              $t_len--;
          } //end if
     } //enf for
 } //end preptext
?>
